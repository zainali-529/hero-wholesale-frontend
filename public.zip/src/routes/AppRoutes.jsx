import { Routes, Route } from 'react-router-dom'
import App from '../App.jsx'
import ProductsPage from '../features/products/ProductsPage.jsx'
import AboutPage from '../features/about/AboutPage.jsx'
import ContactPage from '../features/contact/ContactPage.jsx'
import PartnerPage from '../features/partner/PartnerPage.jsx'

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/products" element={<ProductsPage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="/partner" element={<PartnerPage />} />
    </Routes>
  )
}

export default AppRoutes
