import MainLayout from '../../components/layout/MainLayout.jsx'

function AboutPage() {
  return (
    <MainLayout>
      <section className="mt-4">
        <div className="max-w-2xl space-y-3">
          <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-red-500">
            About
          </p>
          <h1 className="text-xl font-semibold tracking-tight text-slate-900 sm:text-2xl">
            Built for wholesale-first food businesses
          </h1>
          <p className="text-sm text-slate-600 sm:text-[15px]">
            Hero Wholesale Foods focuses on frozen, dry, beverage and packaging
            lines that move in bulk. This is a simple overview page placeholder
            you can expand later with your own story, coverage map and service
            model.
          </p>
        </div>
      </section>
    </MainLayout>
  )
}

export default AboutPage

