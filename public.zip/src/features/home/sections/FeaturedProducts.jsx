import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '../../../components/ui/carousel'
import ProductCard from '../components/ProductCard.jsx'

const sampleProducts = [
  {
    name: 'Apple juice',
    subtitle: '1L foodservice pack',
    price: 40,
    rating: 5,
    ribbon: 'Sale',
    image:
      'https://images.unsplash.com/photo-1577803645773-f96470509666?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Black beans',
    subtitle: '2.5kg restaurant sack',
    price: 22,
    rating: 4,
    ribbonRight: 'Hot',
    image:
      'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Plum silho',
    subtitle: 'Frozen dessert grade',
    price: 40,
    rating: 5,
    image:
      'https://images.unsplash.com/photo-1519985176271-adb1088fa94c?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Strawberry mix',
    subtitle: 'Smoothie & bakery ready',
    price: 35,
    rating: 5,
    image:
      'https://images.unsplash.com/photo-1572441710534-680f2ab38c29?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Cold brew concentrate',
    subtitle: 'Cafe program favourite',
    price: 28,
    rating: 4,
    image:
      'https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Burger cheese slices',
    subtitle: '108 slice catering pack',
    price: 32,
    rating: 5,
    image:
      'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=900&q=80',
  },
]

function FeaturedProducts() {
  return (
    <section className="mt-10">
      <div className="mb-4 flex items-end justify-between gap-3">
        <div className="space-y-1">
          <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-red-500">
            Featured products
          </p>
          <h2 className="text-lg font-semibold tracking-tight text-slate-900 sm:text-xl">
            A quick taste of the range
          </h2>
        </div>
      </div>
      <div className="relative rounded-3xl px-3">
        <Carousel opts={{ align: 'start' }} className="relative">
          <CarouselContent>
            {sampleProducts.map((product) => (
              <CarouselItem
                key={product.name}
                className="basis-1/2 sm:basis-1/3 lg:basis-1/4 py-5"
              >
                <ProductCard product={product} />
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="top-[-2.5rem] left-auto right-11 h-8 w-8 border border-slate-200 bg-white text-slate-700 shadow-sm hover:border-red-300 hover:text-red-600" />
          <CarouselNext className="top-[-2.5rem] right-0 h-8 w-8 border border-slate-200 bg-white text-slate-700 shadow-sm hover:border-red-300 hover:text-red-600" />
        </Carousel>
      </div>
    </section>
  )
}

export default FeaturedProducts
