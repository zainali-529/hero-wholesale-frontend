import { useEffect, useState } from 'react'
import { ChevronDown } from 'lucide-react'
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '../../../components/ui/carousel'
import { Button } from '../../../components/ui/button'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '../../../components/ui/popover'

const banners = [
  {
    image:
      'https://images.unsplash.com/photo-1514933651103-005eec06c04b?auto=format&fit=crop&w=1600&q=80',
  },
  {
    image:
      'https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&w=1600&q=80',
  },
  {
    image:
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1600&q=80',
  },
  {
    image:
      'https://images.unsplash.com/photo-1530023367847-a683933f4172?auto=format&fit=crop&w=1600&q=80',
  },
]

export const categoryGroups = [
  {
    label: 'Frozen & chilled',
    items: [
      'Frozen fries & potatoes',
      'Frozen snacks & appetisers',
      'Ice creams & desserts',
      'Frozen vegetables',
      'Chilled ready-to-eat',
    ],
  },
  {
    label: 'Dry grocery & staples',
    items: [
      'Rice & grains',
      'Pulses & lentils',
      'Flour & baking essentials',
      'Edible oils & ghee',
      'Pasta & noodles',
      'Sugar, salt & spices',
    ],
  },
  {
    label: 'Beverages',
    items: [
      'Soft drinks & sodas',
      'Juices & nectars',
      'Water & flavoured water',
      'Tea, coffee & mixes',
      'Concentrates & syrups',
    ],
  },
  {
    label: 'Dairy, eggs & cheese',
    items: [
      'Milk & cream',
      'Yogurt & cultured products',
      'Cheese blocks & slices',
      'Butter & spreads',
      'Eggs & liquid egg',
    ],
  },
  {
    label: 'Meat, poultry & seafood',
    items: [
      'Chicken cuts & parts',
      'Processed chicken & nuggets',
      'Red meat & mince',
      'Fish & seafood',
      'Cold cuts & deli',
    ],
  },
  {
    label: 'Bakery, snacks & sweets',
    items: [
      'Bread & buns',
      'Tortillas & wraps',
      'Biscuits & cookies',
      'Chips & salty snacks',
      'Cakes, pastries & sweets',
    ],
  },
  {
    label: 'Non‑food & packaging',
    items: [
      'Disposable cups & lids',
      'Food boxes & containers',
      'Bags & wraps',
      'Tissues & napkins',
      'Cleaning & hygiene',
    ],
  },
]

function Banners() {
  const [api, setApi] = useState(null)
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    if (!api) return

    const id = setInterval(() => {
      if (!api) return
      if (api.canScrollNext()) {
        api.scrollNext()
      } else {
        api.scrollTo(0)
      }
    }, 4500)

    return () => clearInterval(id)
  }, [api])

  useEffect(() => {
    if (!api) return

    const onSelect = () => {
      setCurrentIndex(api.selectedScrollSnap())
    }

    onSelect()
    api.on('select', onSelect)

    return () => {
      api.off('select', onSelect)
    }
  }, [api])

  return (
    <section className="mt-3">
      <div className="mb-3 space-y-2">
        <div className="space-y-1">
          <p className="text-[11px] font-semibold uppercase tracking-[0.25em] text-slate-500">
            Browse categories
          </p>
          <p className="text-xs text-slate-500 sm:text-[13px]">
            Quickly scan the types of lines you plan to stock today.
          </p>
        </div>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              className="h-8 rounded-md border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              All categories
              <ChevronDown className="ml-1.5 h-3.5 w-3.5 text-slate-400" />
            </Button>
          </PopoverTrigger>
          <PopoverContent
            align="start"
            className="w-[720px] max-w-[90vw] sm:w-[820px]"
          >
            <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
              All wholesale categories
            </p>
            <p className="mt-1 text-[11px] text-slate-500">
              Scan all lines in one view. Future categories will auto-flow into
              this grid.
            </p>
            <div className="mt-4 grid gap-4 sm:grid-cols-2 md:grid-cols-3">
              {categoryGroups.map((group) => (
                <div key={group.label} className="space-y-1.5">
                  <div className="text-[11px] font-semibold text-slate-800">
                    {group.label}
                  </div>
                  <div className="flex flex-col gap-0.5">
                    {group.items.map((item) => (
                      <div
                        key={item}
                        className="truncate rounded-md bg-slate-50 px-2 py-1 text-[11px] text-slate-700"
                        title={item}
                      >
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </PopoverContent>
        </Popover>
      </div>
      <div className="rounded-3xl border border-slate-100 bg-slate-900/90">
        <Carousel
          opts={{ loop: true, align: 'start' }}
          className="relative"
          setApi={setApi}
        >
          <CarouselContent>
            {banners.map((banner, index) => (
              <CarouselItem key={index}>
                <div className="group relative h-[220px] overflow-hidden bg-slate-900 sm:h-[320px] md:h-[440px]">
                  <img
                    src={banner.image}
                    alt=""
                    className="h-full w-full object-cover transition-transform duration-[900ms] group-hover:scale-105"
                    loading="lazy"
                  />
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="left-3 top-1/2 -translate-y-1/2 border border-white/30 bg-black/40 text-white shadow-sm hover:border-red-400 hover:bg-red-600/80" />
          <CarouselNext className="right-3 top-1/2 -translate-y-1/2 border border-white/30 bg-black/40 text-white shadow-sm hover:border-red-400 hover:bg-red-600/80" />
        </Carousel>
      </div>
      <div className="mt-3 flex items-center justify-center gap-2">
        {banners.map((_, index) => (
          <button
            key={index}
            type="button"
            onClick={() => api && api.scrollTo(index)}
            className={`h-1.5 rounded-full transition-all ${
              currentIndex === index
                ? 'w-5 bg-red-500'
                : 'w-2 bg-slate-300/80 hover:bg-slate-400'
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  )
}

export default Banners
