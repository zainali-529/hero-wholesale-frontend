function ProductCard({ product }) {
  return (
    <div className="group flex h-full flex-col overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-[0_14px_45px_rgba(15,23,42,0.06)] transition-all hover:-translate-y-1 hover:border-red-200/90 hover:shadow-[0_20px_80px_rgba(15,23,42,0.14)]">
      <div className="relative flex items-center justify-center bg-slate-50 px-7 pt-7 pb-5">
        {product.ribbon && (
          <div className="absolute left-0 top-4 rounded-r-full bg-lime-400 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-900">
            {product.ribbon}
          </div>
        )}
        {product.ribbonRight && (
          <div className="absolute right-0 top-4 rounded-l-full bg-lime-400 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-900">
            {product.ribbonRight}
          </div>
        )}
        <div className="relative flex h-32 w-full items-center justify-center sm:h-36">
          <div className="absolute inset-6 rounded-full bg-white/70 blur-2xl" />
          <img
            src={product.image}
            alt={product.name}
            className="relative z-10 h-24 w-auto object-contain sm:h-28"
            loading="lazy"
          />
        </div>
      </div>
      <div className="flex flex-1 flex-col justify-between bg-slate-50/80 px-4 pb-4 pt-3">
        <div className="space-y-1.5">
          <p className="text-[13px] font-semibold tracking-tight text-slate-900 group-hover:text-red-700">
            {product.name}
          </p>
          <p className="text-[11px] text-slate-500">{product.subtitle}</p>
        </div>
        <div className="mt-3 flex items-end justify-between">
          <div className="space-y-0.5">
            <p className="text-[13px] font-semibold text-slate-900">
              ${product.price.toFixed(2)}
            </p>
            <div className="flex items-center gap-0.5 text-[11px] text-amber-400">
              {Array.from({ length: 5 }).map((_, index) => (
                <span
                  key={index}
                  className={
                    index < product.rating
                      ? 'text-amber-400'
                      : 'text-slate-300'
                  }
                >
                  ★
                </span>
              ))}
            </div>
          </div>
          {product.category && (
            <span className="inline-flex rounded-full bg-white px-2 py-1 text-[10px] font-medium text-slate-500 ring-1 ring-slate-200 group-hover:text-red-700 group-hover:ring-red-200">
              {product.category}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}

export default ProductCard
