import { useMemo, useState } from 'react'
import MainLayout from '../../components/layout/MainLayout.jsx'
import { Button } from '../../components/ui/button'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '../../components/ui/popover'
import { ChevronDown } from 'lucide-react'
import ProductCard from '../home/components/ProductCard.jsx'
import { categoryGroups } from '../home/sections/Banners.jsx'

const allProducts = [
  {
    name: 'Skin-on fries 9mm',
    subtitle: '2.5kg frozen catering bag',
    price: 18,
    rating: 5,
    ribbon: 'Popular',
    category: 'Frozen & chilled',
    image:
      'https://images.unsplash.com/photo-1482049016688-2d3e1b311543?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Mozzarella shred',
    subtitle: '2kg pizza cheese blend',
    price: 32,
    rating: 4,
    category: 'Frozen & chilled',
    image:
      'https://images.unsplash.com/photo-1546549032-9571cd6b27df?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Basmati rice XL',
    subtitle: '5kg restaurant sack',
    price: 24,
    rating: 5,
    ribbon: 'Sale',
    category: 'Dry grocery & staples',
    image:
      'https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Mixed pulses blend',
    subtitle: 'Combo for daal of the day',
    price: 19,
    rating: 4,
    category: 'Dry grocery & staples',
    image:
      'https://images.unsplash.com/photo-1522184216316-3c76abb2fjs4?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Orange juice NFC',
    subtitle: '1L chilled, no added sugar',
    price: 14,
    rating: 5,
    category: 'Beverages',
    image:
      'https://images.unsplash.com/photo-1580915411954-282cb1c9c450?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Cola PET 1.5L',
    subtitle: 'Case of 12 bottles',
    price: 27,
    rating: 4,
    category: 'Beverages',
    image:
      'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Burger buns 4”',
    subtitle: '6-pack, sesame topped',
    price: 9,
    rating: 5,
    category: 'Bakery, snacks & sweets',
    image:
      'https://images.unsplash.com/photo-1533777324565-a040eb52fac1?auto=format&fit=crop&w=900&q=80',
  },
  {
    name: 'Brownie slabs',
    subtitle: 'Pre-cut 30 portion tray',
    price: 29,
    rating: 5,
    category: 'Bakery, snacks & sweets',
    image:
      'https://images.unsplash.com/photo-1606312618495-61b077e8ee78?auto=format&fit=crop&w=900&q=80',
  },
]

function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [isOpen, setIsOpen] = useState(false)

  const normalizedCategories = useMemo(
    () =>
      categoryGroups.map((group) => ({
        key: group.label,
        label: group.label,
      })),
    [],
  )

  const filteredProducts = useMemo(() => {
    if (selectedCategory === 'all') return allProducts
    return allProducts.filter(
      (product) => product.category === selectedCategory,
    )
  }, [selectedCategory])

  const selectedLabel =
    selectedCategory === 'all'
      ? 'All categories'
      : normalizedCategories.find((c) => c.key === selectedCategory)?.label ||
        'All categories'

  return (
    <MainLayout>
      <section className="mt-6">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div className="space-y-1">
            <p className="text-[11px] font-semibold uppercase tracking-[0.26em] text-red-500">
              Products
            </p>
            <h1 className="text-xl font-semibold tracking-tight text-slate-900 sm:text-2xl">
              Browse wholesale lines by category
            </h1>
            <p className="max-w-xl text-xs text-slate-500 sm:text-[13px]">
              Start with a broad category and then drill down into SKUs that fit
              your menu, store or delivery model.
            </p>
          </div>

          <div className="sm:text-right">
            <p className="text-[11px] uppercase tracking-[0.22em] text-slate-500">
              Category filter
            </p>
            <Popover open={isOpen} onOpenChange={setIsOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-1 h-9 rounded-md border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  {selectedLabel}
                  <ChevronDown className="ml-1.5 h-3.5 w-3.5 text-slate-400" />
                </Button>
              </PopoverTrigger>
              <PopoverContent
                align="end"
                className="w-[320px] max-w-[90vw] sm:w-[360px]"
              >
                <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-slate-500">
                  Filter by category
                </p>
                <p className="mt-1 text-[11px] text-slate-500">
                  Pick a broad storage or usage group to see matching sample
                  products.
                </p>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCategory('all')
                      setIsOpen(false)
                    }}
                    className={`rounded-full border px-2.5 py-1 text-[11px] ${
                      selectedCategory === 'all'
                        ? 'border-red-500 bg-red-50 text-red-700'
                        : 'border-slate-200 bg-white text-slate-600 hover:border-red-300 hover:text-red-700'
                    }`}
                  >
                    All categories
                  </button>
                  {normalizedCategories.map((cat) => (
                    <button
                      key={cat.key}
                      type="button"
                      onClick={() => {
                        setSelectedCategory(cat.key)
                        setIsOpen(false)
                      }}
                      className={`rounded-full border px-2.5 py-1 text-[11px] ${
                        selectedCategory === cat.key
                          ? 'border-red-500 bg-red-50 text-red-700'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-red-300 hover:text-red-700'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {filteredProducts.map((product) => (
            <ProductCard key={product.name} product={product} />
          ))}
        </div>
      </section>
    </MainLayout>
  )
}

export default ProductsPage

