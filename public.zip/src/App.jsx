import HomePage from './features/home/HomePage.jsx'

function App() {
  return <HomePage />
}

export default App
